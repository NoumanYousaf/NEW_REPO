<?php
$con = mysqli_connect("localhost","root","","plants_db");
if(!$con)
    die("Connection failed");