<!DOCTYPE html>
<html>
<head>
      <title>Registration Form</title>
	  <link rel="stylesheet" href="css/style1.css">
	  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
    <body>
	   <div>
		 <?php
			$con = mysqli_connect("localhost", "root", "", "plants_db");
			if (!$con)
				die("Connection failed");
			?>
	     <?php
		    if(isset($_POST['create'])){
			    $cust_name = test_input($_POST['cust_name']);
				$cust_address = test_input($_POST['cust_address']);
				$cust_contact = test_input($_POST['cust_contact']);
				$cust_email = test_input($_POST['cust_email']);
				$cust_pass = test_input($_POST['cust_pass']);
			
				if (!preg_match("/[a-zA-Z]+/", $cust_name) || strlen($cust_name) < 2) {
				$response = array(
				"type" => "warning",
				"message" => "Enter Valid Name."
					);
				} else {
					 $add_customer = "insert into customers (cust_name, cust_email, cust_pass, cust_contact, cust_address)
					 VALUES ('$cust_name', '$cust_email', '$cust_pass', '$cust_contact', '$cust_address')";
					 $add_cust = mysqli_query($con, $add_customer);
					 if($add_cust){
						 $response = array(
							"type" => "success",
							"message" => "Customer add successfully."
						 );
					 }
				}
			}
			function test_input($data)
			{
				$data = trim($data);
				$data = stripslashes($data);
				$data = htmlspecialchars($data);
				return $data;
			}

			?>
		 <header id="ha">
		   <div class="main">
			<ul>
				<li><a href="Home.html">Home</a></li>
				<li class="active"><a href="Reg.php">Register</a></li>
				<li><a href="#">Contact</a></li>
			</ul>
		   </div>
		   <br><br>
			 <h1 id="ht">Registration</h1>
			<div class="register">
			<form id="register" action="Reg.php" method="POST">
			   <div class="container">
			     <div class="row">
				 <div class="col-sm-3">
				  <h2>Register Here</h2>
				  <label>Name:</label><br>
				  <input type="text" name="cust_name" class="form-control" id="name" placeholder="Name"><br><br>
				  <label>Address:</label><br>
				  <input type="address" name="cust_address" class="form-control" id="name" placeholder="Address"><br><br>
				  <label>Mobile Number:</label><br>
				  <input type="number" name="cust_contact" class="form-control" id="name" placeholder="MobileNumber"><br><br>
				  <label>Email:</label><br>
				  <input type="email" name="cust_email" class="form-control" id="name" placeholder="Email"><br><br>
				  <label>Password:</label><br>
				  <input type="password" name="cust_pass" class="form-control" id="name"><br><br>
				  <label>Confirm Password:</label><br>
				  <input type="password" name="cust_pass" class="form-control" id="name"><br><br>
				  
				  <button type="submit" id="sub" name="create" onclick="Validation()">Sign Up</button>
				 </div>
				 </div>
			   </div>
			</form>
			</div>
		 </header>
		 <script>
	        function Validation()
			{
				let nameformat=/^[a-zA-Z]+$/g;
				let inputName=document.getElementByName("Name").value;
				let result=inputName.match(nameformat);
				if(result)
				{
					alert("Valid Name");
				}
				else
				{
				    alert("You have entered an invalid name!");
				}
			    
				let mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
				let inputEmail=document.getElementByName("Email").value;
				let result1=inputName.match(mailformat);
				if(result1)
				{
					alert("Valid Email");
				}
				else
				{
					alert("You have entered an invalid email address!");
				F
				
				let phonenumberformat = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/g;  
				let inputph=document.getElementByName("num").value;
				let result2=inputName.match(phonenumberformat);
				if(result2)
				{
					alert("Valid Phone Number");
				}
				else
				{
					alert("You have entered an invalid phone number!");
				}
				
				let addressformat=/^[a-zA-Z0-9\s,'-]*$/g;
				let inputaddress=document.getElementByName("Address").value;
				let result2=inputName.match(mailformat);
				if(result2)
				{
					alert("Valid Address");
				}
				else
				{
					alert("You have entered an invalid address!");
				}
				
			}
	</script>

	</body>
</html>
